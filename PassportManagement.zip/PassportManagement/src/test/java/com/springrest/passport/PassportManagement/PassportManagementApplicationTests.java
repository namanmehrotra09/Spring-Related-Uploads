package com.springrest.passport.PassportManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassportManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
