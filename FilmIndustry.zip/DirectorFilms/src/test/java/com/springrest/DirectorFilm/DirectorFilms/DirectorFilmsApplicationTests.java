package com.springrest.DirectorFilm.DirectorFilms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DirectorFilmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
