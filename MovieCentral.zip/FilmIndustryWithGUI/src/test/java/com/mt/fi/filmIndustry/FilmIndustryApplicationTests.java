package com.mt.fi.filmIndustry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmIndustryApplicationTests {

	@Test
	void contextLoads() {
	}

}
