package com.mt.fi.filmIndustry.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mt.fi.filmIndustry.entities.Director;

public interface DirectorsRepository extends JpaRepository<Director, String>{

}
