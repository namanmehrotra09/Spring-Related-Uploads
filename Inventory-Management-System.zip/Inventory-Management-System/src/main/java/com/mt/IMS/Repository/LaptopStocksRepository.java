package com.mt.IMS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mt.IMS.Entities.LaptopStocks;

public interface LaptopStocksRepository extends JpaRepository<LaptopStocks, Long>{

}
